HBaseThrift
===========

Sample code for working with HBase Thrift.